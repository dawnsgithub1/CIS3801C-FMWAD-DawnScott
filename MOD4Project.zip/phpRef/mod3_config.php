<?php
// This is an example of config.php
$dbhost = 'localhost';
$dbuser = 'fmwadvmAdmin';
$dbpass = 'fmwadvmPassW1';
$dbname = 'mysampledb';
?>
